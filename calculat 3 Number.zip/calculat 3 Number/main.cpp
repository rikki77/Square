#include <iostream>

using namespace std;

int main()
{
    cout << "Enter one side of the right rectangle " << endl;

    int a;
    cin >> a;
    cout << "Enter the second Number " << endl;
    int b;
    cin >> b;
    cout << "Enter the Third Number " << endl;
    int d;
    cin >> d;
    int J = a + b + d;

    cout << "Answer is: " << J << "" << endl;


    return 0;
}
